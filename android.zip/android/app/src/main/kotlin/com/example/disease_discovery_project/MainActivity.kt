package com.example.disease_discovery_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
